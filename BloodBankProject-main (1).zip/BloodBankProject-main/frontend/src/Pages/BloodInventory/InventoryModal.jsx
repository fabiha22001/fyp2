import React, { useState } from "react";
import { Modal } from "flowbite-react";
import { Link } from "react-router-dom";
import { BASE_URL, token } from "../../../config";
import { toast } from "react-toastify";
import { useInventoryContext } from "../../context/InventoryContext";

const InventoryModal = () => {
  const [openModal, setOpenModal] = useState(false);
  const [bloodbank, setBloodbank] = useState("");
  const [blood, setBlood] = useState([
    { bloodGroup: "", quantity: 1, available: "available" },
  ]);
  const { getInventoryData, inventory } = useInventoryContext();
  function onCloseModal(e) {
    e.preventDefault();
    setOpenModal(false);
  }

  const handleBloodChange = (index, e) => {
    const newBlood = blood.slice();
    newBlood[index][e.target.name] = e.target.value;
    setBlood(newBlood);
  };

  const handleAddBlood = () => {
    setBlood([
      ...blood,
      { bloodGroup: "", quantity: 0, available: "available" },
    ]);
  };

  const handleRemoveBlood = (index) => {
    const newBlood = blood.slice();
    newBlood.splice(index, 1);
    setBlood(newBlood);
  };

  const handleSubmit = async (e) => {
    try {
      e.preventDefault();
      const res = await fetch(`${BASE_URL}/admin/addrecord`, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ bloodbank, blood }),
      });
      const result = await res.json();

      if (!res.ok) {
        toast.error(result.message);
        throw new Error(result.message);
      }
      getInventoryData(result.data);
      setOpenModal(false);
      setBlood([{ bloodGroup: "", quantity: 0, available: "available" }]);
      setBloodbank("");
      toast.success(result.message);
    } catch (error) {
      toast.error(error);
    }
  };

  return (
    <>
      <Link
        type="button"
        class="mt-8 inline-block rounded bg-backgroundColor px-12 py-3 text-sm font-medium text-white transition hover:bg-[#4d4d4d]"
        onClick={() => setOpenModal(true)}
      >
        Add New Record
      </Link>
      <Modal show={openModal} size="lg" onClose={onCloseModal} popup>
        <Modal.Header />
        <Modal.Body>
          <div className="space-y-8">
            <h3 className="text-xl font-medium text-gray-900 dark:text-white">
              Add New Inventory Record
            </h3>
            <form onSubmit={handleSubmit}>
              <div className="mt-4">
                <label>
                  Blood Bank:
                  <input
                    type="text"
                    value={bloodbank}
                    onChange={(e) => setBloodbank(e.target.value)}
                    className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-backgroundColor-500 focus:border-backgroundColor-500 block w-full p-2.5"
                    required
                  />
                </label>
              </div>
              {blood.map((bloodItem, index) => (
                <div key={index} className="flex flex-col gap-4 mt-4">
                  <label>
                    Blood Group:
                    <select
                      type="text"
                      name="bloodGroup"
                      value={bloodItem.bloodGroup}
                      onChange={(e) => handleBloodChange(index, e)}
                      className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-backgroundColor-500 focus:border-backgroundColor-500 block w-full p-2.5"
                    >
                      <option value="">Select</option>
                      <option value="A+">A+</option>
                      <option value="B+">B+</option>
                      <option value="O+">O+</option>
                      <option value="A-">A-</option>
                      <option value="B-">B-</option>
                      <option value="O-">O-</option>
                      <option value="AB+">AB+</option>
                      <option value="AB-">AB-</option>
                    </select>
                  </label>
                  <label>
                    Quantity:
                    <input
                      type="number"
                      name="quantity"
                      value={bloodItem.quantity}
                      onChange={(event) => handleBloodChange(index, event)}
                      className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-backgroundColor-500 focus:border-backgroundColor-500 block w-full p-2.5"
                    />
                  </label>
                  <label>
                    Availability:
                    <select
                      name="available"
                      value={bloodItem.available}
                      onChange={(event) => handleBloodChange(index, event)}
                      className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-backgroundColor-500 focus:border-backgroundColor-500 block w-full p-2.5"
                    >
                      <option value="available">Available</option>
                      <option value="non-available">Non-available</option>
                    </select>
                  </label>
                  <button
                    type="button"
                    onClick={() => handleRemoveBlood(index)}
                    className="mt-8 inline-block rounded bg-backgroundColor px-12 py-3 text-sm font-medium text-white transition hover:bg-[#4d4d4d]"
                  >
                    Remove
                  </button>
                </div>
              ))}
              <div className="flex justify-between">
                <button
                  type="button"
                  onClick={handleAddBlood}
                  className="mt-8 inline-block rounded bg-backgroundColor px-12 py-3 text-sm font-medium text-white transition hover:bg-[#4d4d4d]"
                >
                  Add Blood Entry
                </button>
                <button
                  type="submit"
                  className="mt-8 inline-block rounded bg-backgroundColor px-12 py-3 text-sm font-medium text-white transition hover:bg-[#4d4d4d]"
                >
                  Submit
                </button>
              </div>
            </form>
          </div>
        </Modal.Body>
      </Modal>
    </>
  );
};

export default InventoryModal;

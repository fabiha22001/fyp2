import React from "react";
import blood from "../../assets/images/blood-drop.png";
import { Link } from "react-router-dom";
import HideMiddleDigits from "../../utils/HideMiddleDigits";

const PatientCard = ({ data }) => {
  const { name, email, age, bloodGroup, phone, role } = data;
  return (
    // <div>
    //   <div>
    //     <a
    //       href="#"
    //       class="flex flex-row items-center bg-white border border-gray-200 rounded-lg shadow md:flex-row md:max-w-xl hover:bg-gray-100 dark:border-gray-700 dark:bg-gray-800 dark:hover:bg-gray-700"
    //     >
    //       <img
    //         class="w-[35%] rounded-t-lg md:h-full md:w-[28%] md:rounded-none md:rounded-s-lg "
    //         src={blood}
    //         alt="bloodImg"
    //       />

    //       <div class="flex flex-col justify-between p-4 leading-normal">
    //         <h5 class="mb-2 text-2xl font-bold tracking-tight text-gray-900 dark:text-white">
    //           {name}
    //         </h5>
    //         <p class="mb-3 font-normal text-gray-700 dark:text-gray-400">
    //           {email}
    //         </p>
    //         <p class="mb-3 font-normal text-gray-700 dark:text-gray-400">
    //           {age}
    //         </p>
    //         <p class="mb-3 font-normal text-gray-700 dark:text-gray-400">
    //           {phone}
    //         </p>
    //         <p class="mb-3 font-normal text-gray-700 dark:text-gray-400">
    //           {role}
    //         </p>
    //         <p class="mb-3 font-normal text-gray-700 dark:text-gray-400">
    //           {bloodGroup}
    //         </p>
    //       </div>
    //     </a>
    //   </div>
    // </div>

    <section class="relative block overflow-hidden rounded-lg border border-gray-100 p-4 sm:p-6 lg:p-8">
      <span class="absolute inset-x-0 bottom-0 h-2 bg-gradient-to-r from-red-300 via-red-500 to-red-600"></span>

      <div class="sm:flex sm:justify-between sm:gap-4">
        <div>
          <h3 class="text-[25px] font-bold text-gray-900">{bloodGroup}</h3>
          <div class="mt-2">
            <p class="text-sm font-medium text-gray-600">Name</p>
            <p class="text-[18px] font-800 text-gray-900 sm:text-xl">{name}</p>
          </div>
        </div>

        <div class="hidden sm:block sm:shrink-0">
          <img
            alt=""
            src={blood}
            class="size-16 rounded-lg object-cover shadow-sm"
          />
        </div>
      </div>

      <div class="mt-2">
        <p class="text-sm font-medium text-gray-600">Age</p>
        <p class="text-pretty text-sm text-gray-500">{age}</p>
      </div>

      <div class="mt-2">
        <p class="text-sm font-medium text-gray-600">Contact</p>
        <p class="text-pretty text-sm text-gray-500">
          {" "}
          <HideMiddleDigits contactNumber={phone} />
        </p>
      </div>

      <div class="mt-2">
        <p class="text-sm font-medium text-gray-600">Email</p>
        <p class="text-pretty text-sm text-gray-800 text-[16px]">
          {" "}
          <HideMiddleDigits contactNumber={email} />
        </p>
      </div>

      {/* <Link
        to=""
        class="mt-8 inline-block rounded bg-backgroundColor px-12 py-3 text-sm font-medium text-white transition hover:bg-[#4d4d4d]"
      >
        Want to Donat Blood
      </Link> */}
    </section>
  );
};

export default PatientCard;

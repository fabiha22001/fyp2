import React from "react";
import { Link } from "react-router-dom";

const Home = () => {
  const backgroundImg =
    "https://media.istockphoto.com/id/937685536/vector/blood-doner-day.jpg?s=612x612&w=0&k=20&c=f5lfl6n4uEV4xKxpJrFgvVJc8cbdc4LdjgSv7Vgjggc=";

  return (
    <>
      <section>
        <div class="mx-auto max-w-screen-xl px-4 py-8 sm:px-6 sm:py-12 lg:px-8 lg:py-16">
          <div class="grid grid-cols-1 gap-8 lg:grid-cols-2 lg:gap-16">
            <div class="relative h-64 overflow-hidden rounded-lg sm:h-80 lg:order-last lg:h-full">
              <img
                alt=""
                src={backgroundImg}
                class=" h-full w-full object-cover"
              />
            </div>

            <div class="lg:py-24">
              <h2 class="text-3xl font-bold sm:text-4xl">Get Started Today</h2>

              <p class="mt-4 text-gray-600">
                Blood donation is a vital part of worldwide healthcare. It
                relates to blood transfusion as a life-sustaining and
                life-saving procedure as well as a form of therapeutic
                phlebotomy as a primary medical intervention. Over one hundred
                million units of blood are donated each year throughout the
                world.
              </p>

              <Link
                to="/login"
                class="mt-8 mr-3 inline-block rounded hover:bg-backgroundColor px-12 py-3 text-sm font-medium text-white transition bg-[#4d4d4d] "
              >
                Login to Account
              </Link>
              <Link
                to="/register"
                class="mt-8  inline-block rounded bg-backgroundColor px-12 py-3 text-sm font-medium text-white transition hover:bg-[#4d4d4d] "
              >
                Register Now
              </Link>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default Home;

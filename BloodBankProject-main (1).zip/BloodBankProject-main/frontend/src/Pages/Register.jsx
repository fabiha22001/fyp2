import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { FaRegEye } from "react-icons/fa";
import { FaRegEyeSlash } from "react-icons/fa";
import HashLoader from "react-spinners/HashLoader";
import { toast } from "react-toastify";
import { BASE_URL } from "../../config";

const Register = () => {
  const [loading, setLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);

  const [RegisterformData, setRegisterformData] = useState({
    name: "",
    email: "",
    password: "",
    confirmpassword: "",
    phone: "",
    age: "",
    gender: "",
    role: "",
    bloodGroup: "",
    lastDonationDate: "",
  });

  console.log(RegisterformData);

  const navigate = useNavigate();

  const HandleLoginInput = (e) => {
    e.preventDefault();
    setRegisterformData({
      ...RegisterformData,
      [e.target.name]: e.target.value,
    });
  };

  const togglePasswordVisibility = () => {
    setShowPassword(!showPassword);
  };
  const HandleSubmit = async (e) => {
    e.preventDefault();
    try {
      const res = await fetch(`${BASE_URL}/auth/register`, {
        method: "post",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(RegisterformData),
      });
      const { message } = await res.json();

      if (!res.ok) {
        toast.error(message);
        throw new Error(message);
      }
      toast.success(message);
      setLoading(false);
      navigate("/login");
    } catch (error) {
      console.log(error);
      toast.error(error);
    }
  };

  return (
    <>
      <section className="py-5 lg:px-0">
        <div className="w-full max-w-[570px] mx-auto rounded-lg shadow-md md:p-10 p-10 ">
          <h3 className="text-headingColor text-[22px] font-bold leading-9">
            Create a New<span className="text-backgroundColor"> Account</span>
            🎉
          </h3>
          <form className="py-4 md:py-0" onSubmit={HandleSubmit}>
            <div className="my-5">
              <input
                type="text"
                placeholder="Enter Your Full Name"
                name="name"
                value={RegisterformData.name}
                onChange={HandleLoginInput}
                required
                className="w-full px-4 py-3 border-b border-solid border-backgroundColor
           focus:outline-none focus:border-b-backgroundColor leading-7 text-headingColor text-[19px]
           placeholder:text-greyColor rounded-md cursor-pointer focus:ring-backgroundColor "
              />
            </div>
            <div className="my-5">
              <input
                type="email"
                placeholder="Enter Your Email"
                name="email"
                value={RegisterformData.email}
                onChange={HandleLoginInput}
                required
                className="w-full px-4 py-3 border-b border-solid border-primaryColor
           focus:outline-none focus:border-b-primaryColor leading-7 text-headingColor text-[19px]
           placeholder:text-greyColor rounded-md cursor-pointer focus:ring-primaryColor"
              />
              <p
                id="helper-text-explanation"
                class="mt-2 text-sm text-yellow-400 dark:text-gray-400"
              >
                Provide a Valid or Active Email Address by which doner/patient
                can contact easily
              </p>
            </div>
            <div className="my-5 flex relative">
              <input
                type={showPassword ? "text" : "password"}
                placeholder="Enter Your Password"
                name="password"
                value={RegisterformData.password}
                onChange={HandleLoginInput}
                required
                className="w-full px-4 py-3 border-b border-solid border-primaryColor
           focus:outline-none focus:border-b-primaryColor leading-7 text-headingColor text-[19px]
           placeholder:text-greyColor rounded-md cursor-pointer focus:ring-backgroundColor"
              />
              <div
                className="absolute flex justify-end bottom-[20px] left-[88%] w-10 overflow-hidden"
                onClick={togglePasswordVisibility}
              >
                {!showPassword ? <FaRegEyeSlash /> : <FaRegEye />}
              </div>
            </div>

            <div className="my-5 flex relative">
              <input
                type={showPassword ? "text" : "password"}
                placeholder="Enter Your Confirm Password"
                name="confirmpassword"
                value={RegisterformData.confirmpassword}
                onChange={HandleLoginInput}
                required
                className="w-full px-4 py-3 border-b border-solid border-primaryColor
           focus:outline-none focus:border-b-primaryColor leading-7 text-headingColor text-[19px]
           placeholder:text-greyColor rounded-md cursor-pointer focus:ring-backgroundColor"
              />
              <div
                className="absolute flex justify-end bottom-[20px] left-[88%] w-10 overflow-hidden"
                onClick={togglePasswordVisibility}
              >
                {!showPassword ? <FaRegEyeSlash /> : <FaRegEye />}
              </div>
            </div>

            <div className="my-5">
              <input
                type="number"
                placeholder="Enter Your Age"
                name="age"
                value={RegisterformData.age}
                onChange={HandleLoginInput}
                required
                className="w-full px-4 py-3 border-b border-solid border-b-primaryColor
            focus:border-primaryColor leading-7 text-headingColor text-[19px]
           placeholder:text-greyColor rounded-md cursor-pointer focus:ring-backgroundColor"
              />
            </div>

            <div className="my-5">
              <input
                type="number"
                placeholder="Enter Your Phone Number"
                name="phone"
                value={RegisterformData.phone}
                onChange={HandleLoginInput}
                required
                className="w-full px-4 py-3 border-b border-solid border-primaryColor
           focus:outline-none focus:border-b-primaryColor leading-7 text-headingColor text-[19px]
           placeholder:text-greyColor rounded-md cursor-pointer focus:ring-backgroundColor"
              />
            </div>

            <div className="mb-5 flex justify-between items-center">
              <label className="text-headingColor font-bold text-[16px] leading-7">
                Are you a:
                <select
                  onChange={HandleLoginInput}
                  value={RegisterformData.role}
                  required
                  name="role"
                  className="text-greyColor font-semibold 
                text-[15px] leading-7 outline-none focus:outline-none py-1 focus:ring-backgroundColor "
                >
                  <option value="">Select</option>
                  <option value="doner">Doner</option>
                  <option value="patient">Patient</option>
                </select>
              </label>

              <label className="text-headingColor font-bold text-[16px] leading-7">
                Gender:
                <select
                  required
                  onChange={HandleLoginInput}
                  value={RegisterformData.gender}
                  name="gender"
                  className="text-greyColor font-semibold 
                text-[15px] leading-7 focus:outline-none py-1 outline-none focus:ring-backgroundColor"
                >
                  <option value="">Select</option>
                  <option value="male">Male</option>
                  <option value="female">Female</option>
                  <option value="other">Other</option>
                </select>
              </label>

              <label className="text-headingColor font-bold text-[16px] leading-7">
                Blood Group:
                <select
                  required
                  onChange={HandleLoginInput}
                  value={RegisterformData.bloodGroup}
                  name="bloodGroup"
                  className="text-greyColor font-semibold 
                text-[15px] leading-7 outline-none focus:outline-none py-1 focus:ring-backgroundColor"
                >
                  <option value="">Select</option>
                  <option value="A+">A+</option>
                  <option value="B+">B+</option>
                  <option value="O+">O+</option>
                  <option value="A-">A-</option>
                  <option value="B-">B-</option>
                  <option value="O-">O-</option>
                  <option value="AB+">AB+</option>
                  <option value="AB-">AB-</option>
                </select>
              </label>
            </div>
            {RegisterformData.role === "doner" && (
              <div className="my-5">
                <input
                  type="date"
                  placeholder="Enter Last Donation Date"
                  name="lastDonationDate"
                  value={RegisterformData.lastDonationDate}
                  onChange={HandleLoginInput}
                  className="w-full px-4 py-3 border-b border-solid border-primaryColor
           focus:outline-none focus:border-b-primaryColor leading-7 text-headingColor text-[19px]
           placeholder:text-greyColor rounded-md cursor-pointer focus:ring-backgroundColor"
                />
                <p
                  id="helper-text-explanation"
                  class="mt-2 text-sm text-yellow-400 dark:text-gray-400"
                >
                  If you not donate blood yet! leave this field blank
                </p>
              </div>
            )}

            <button
              disabled={loading && true}
              type="submit"
              className="btn w-full rounded-md text-[16px] hover:shadow-lg"
            >
              {loading ? <HashLoader size={35} color="#fffff" /> : "Register"}
            </button>
            <p className="mt-5 text-greyColor text-center">
              Already have an account?
              <Link to="/login" className="font-semibold text-primaryColor">
                Login
              </Link>
            </p>
          </form>
        </div>
      </section>
    </>
  );
};

export default Register;

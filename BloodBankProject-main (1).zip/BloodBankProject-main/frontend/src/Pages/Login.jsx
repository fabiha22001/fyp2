import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { toast } from "react-toastify";
import { BASE_URL } from "../../config";
import { useAuthContext } from "../context/authContext";
import { FaRegEye } from "react-icons/fa";
import { FaRegEyeSlash } from "react-icons/fa";

const Login = () => {
  const [loading, setLoading] = useState();
  const [showPassword, setShowPassword] = useState(false);
  const [formData, setFormData] = useState({
    email: "",
    password: "",
  });

  const { getUserData } = useAuthContext();

  const navigate = useNavigate();

  const HandleLoginInput = (e) => {
    e.preventDefault();
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const loginSubmit = async (e) => {
    e.preventDefault();
    try {
      const res = await fetch(`${BASE_URL}/auth/login`, {
        method: "post",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(formData),
      });

      const result = await res.json();

      if (!res.ok) {
        toast.error(result.message);
        throw new Error(result.message);
      }
      toast.success(result.message);
      setLoading(false);
      navigate("/dashboard");
      getUserData(result.data, result.data.token, result.data.role);
    } catch (error) {
      console.log(error);
      toast.error(error);
    }
  };

  const togglePasswordVisibility = () => {
    setShowPassword(!showPassword);
  };

  return (
    <>
      <section className="py-5 my-10 lg:px-0">
        <div className="w-full max-w-[570px] mx-auto rounded-lg shadow-md md:p-10 p-10 ">
          <h3 className="text-headingColor text-[22px] font-bold leading-9">
            Hello<span className="text-dark"> Welcome</span> Back 🎉
          </h3>
          <form className="py-4 md:py-0" onSubmit={loginSubmit}>
            <div className="my-5">
              <input
                type="email"
                placeholder="Enter Your Email"
                name="email"
                value={FormData.email}
                onChange={HandleLoginInput}
                required
                className="w-full px-4 py-3 border-b border-solid border-backgroundColor
               focus:outline-none focus:border-b-primaryColor leading-7 text-dark text-[19px]
               placeholder:text-greyColor rounded-md cursor-pointer focus:ring-backgroundColor"
              />
            </div>
            <div className="my-5 relative">
              <input
                type={showPassword ? "text" : "password"}
                placeholder="Enter Your Password"
                name="password"
                value={FormData.password}
                onChange={HandleLoginInput}
                required
                className="w-full px-4 py-3 border-b border-solid border-backgroundColor
               focus:outline-none focus:border-b-backgroundColor leading-7 text-dark text-[19px]
               placeholder:text-greyColor rounded-md cursor-pointer focus:ring-backgroundColor"
              />
              <div
                className="absolute flex justify-end bottom-[20px] left-[88%] w-10 overflow-hidden"
                onClick={togglePasswordVisibility}
              >
                {!showPassword ? <FaRegEyeSlash /> : <FaRegEye />}
              </div>
            </div>

            <button
              type="submit"
              className="btn w-full rounded-md text-[16px] hover:shadow-lg bg-backgroundColor"
            >
              {loading ? <HashLoader size={35} color="#fffff" /> : "Login"}
            </button>
            <div className="grid grid-cols-2"></div>
            <p className="mt-5 text-dark text-center">
              Don't have an account?
              <Link
                to="/register"
                className="font-semibold text-backgroundColor"
              >
                Register
              </Link>
            </p>
          </form>
        </div>
      </section>
    </>
  );
};

export default Login;

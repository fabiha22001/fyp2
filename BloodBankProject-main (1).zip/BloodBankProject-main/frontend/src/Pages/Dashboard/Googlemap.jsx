import { GoogleMap, LoadScript } from "@react-google-maps/api";
import React from "react";

const Googlemap = () => {
  const mapContainerStyle = {
    width: "100%",
    height: "70vh",
  };

  return (
    <div>
      <div className="p-4 sm:ml-64">
        <div className="p-4 border-2 border-gray-200 border-dashed rounded-lg dark:border-gray-700 mt-14">
          <div className="grid grid-cols-1 gap-4 mb-4">
            {/* <div className="flex items-center justify-center h-24 rounded bg-gray-50 dark:bg-gray-800"></div> */}
            <LoadScript googleMapsApiKey="">
              <GoogleMap mapContainerStyle={mapContainerStyle}></GoogleMap>
            </LoadScript>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Googlemap;

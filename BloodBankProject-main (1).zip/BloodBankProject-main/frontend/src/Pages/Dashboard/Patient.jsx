import React from "react";
import PatientCardList from "../Patient/PatientCardList";

const Patient = () => {
  return (
    <div>
      <div className="p-4 sm:ml-64">
        <div className="p-4 border-2 border-gray-200 border-dashed rounded-lg dark:border-gray-700 mt-14">
          <h1 className="text-[30px] my-6 font-bold capitalize">
            All Patients Record{" "}
          </h1>
          <div class="grid grid-col-2 grid-flow-col gap-4">
            <PatientCardList />
          </div>
        </div>
      </div>
    </div>
  );
};

export default Patient;

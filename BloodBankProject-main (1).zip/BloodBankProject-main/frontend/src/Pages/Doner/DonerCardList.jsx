import React from "react";
import DonerCard from "./DonerCard";
import { BASE_URL } from "../../../config.js";
import useFetchData from "../../hook/useFetchData.jsx";
import { Loading } from "../../utils/LoadingTable.jsx";

const DonerCardList = () => {
  const { loading, data, error } = useFetchData(`${BASE_URL}/doner/`);
  return (
    <div>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {loading && <Loading />}
        {!loading &&
          !error &&
          data.map((curElem, index) => {
            return <DonerCard key={index} donerData={curElem} />;
          })}
      </div>
    </div>
  );
};

export default DonerCardList;

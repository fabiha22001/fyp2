import React from "react";
import { Routes, Route } from "react-router-dom";
import Login from "../Pages/Login";
import Register from "../Pages/Register";
import Dashboard from "../Pages/Dashboard/Dashboard";
import Googlemap from "../Pages/Dashboard/Googlemap";
import ProtectedRoutes from "./ProtectedRoutes";
import Navigation from "../Pages/Dashboard/Navigation";
import Doner from "../Pages/Dashboard/Doner";
import Error from "../Pages/Error";
import Setting from "../Pages/Dashboard/Setting";
import { useAuthContext } from "../context/authContext";
import Patient from "../Pages/Dashboard/Patient";
import Home from "../Pages/Home";
import AdminDoner from "../Pages/Dashboard/AdminDoner";
import AdminUser from "../Pages/Dashboard/AdminUser";
import AdminUpdate from "../Pages/Dashboard/AdminUpdate";
import AdminPatientUpdate from "../Pages/Dashboard/AdminPatientUpdate";
import Inventory from "../Pages/BloodInventory/Inventory";
import Requests from "../Pages/Dashboard/Requests";

const Router = () => {
  const { role } = useAuthContext();
  return (
    <>
      <Routes>
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route path="/" element={<Home />} />
        <Route path="*" element={<Error />} />
        <Route path="admin/doner/update/:id" element={<AdminUpdate />} />
        <Route path="admin/user/update/:id" element={<AdminPatientUpdate />} />
        <Route
          path="/dashboard"
          element={
            <ProtectedRoutes allowedRoles={["patient", "doner", "admin"]}>
              <Dashboard />
            </ProtectedRoutes>
          }
        />
        {role === "patient" && <Route path="/doner" element={<Doner />} />}

        {role === "doner" && <Route path="/patient" element={<Patient />} />}

        <Route
          path="/google-map-view"
          element={
            <ProtectedRoutes allowedRoles={["patient", "doner"]}>
              <Googlemap />
            </ProtectedRoutes>
          }
        />
        <Route
          path="/setting"
          element={
            <ProtectedRoutes allowedRoles={["patient", "doner"]}>
              <Setting />
            </ProtectedRoutes>
          }
        />

        <Route
          path="/my-requests"
          element={
            <ProtectedRoutes allowedRoles={["patient", "doner"]}>
              <Requests />
            </ProtectedRoutes>
          }
        />

        <Route
          path="/admin/admin-users"
          default
          element={
            <ProtectedRoutes allowedRoles={["admin"]}>
              <AdminUser />
            </ProtectedRoutes>
          }
        />
        <Route
          path="/admin/admin-doners"
          element={
            <ProtectedRoutes allowedRoles={["admin"]}>
              <AdminDoner />
            </ProtectedRoutes>
          }
        />
        <Route
          path={
            role === "admin" ? "/admin/blood-inventory" : "/blood-inventory"
          }
          element={
            <ProtectedRoutes allowedRoles={["admin", "patient"]}>
              <Inventory />
            </ProtectedRoutes>
          }
        />
      </Routes>

      <Navigation />
    </>
  );
};

export default Router;

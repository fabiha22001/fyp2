import { React } from "react";
import { useAuthContext } from "../context/authContext";
import { Navigate } from "react-router-dom";

const ProtectedRoutes = ({ children, allowedRoles }) => {
  const { role, token } = useAuthContext();
  const isAllow = allowedRoles.includes(role);
  const accessableRoute =
    token && isAllow ? children : <Navigate to="/login" replace={true} />;
  return accessableRoute;
};

export default ProtectedRoutes;

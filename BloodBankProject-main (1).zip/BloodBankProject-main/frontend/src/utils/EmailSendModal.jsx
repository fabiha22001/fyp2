import React, { useState } from "react";
import { Button, Checkbox, Label, Modal, TextInput } from "flowbite-react";
import { Link } from "react-router-dom";
import { useAuthContext } from "../context/authContext";
import { BASE_URL } from "../../config";
import { toast } from "react-toastify";

const EmailSendModal = ({ donerDetails }) => {
  const [openModal, setOpenModal] = useState(false);

  function onCloseModal(e) {
    e.preventDefault();
    setOpenModal(false);
  }
  const { _id, name, email, contact, bloodGroup } = donerDetails;

  const { data } = useAuthContext();
  const [RequestformData, setRequestformData] = useState({
    name: data.name,
    email: data.email,
    phone: data.phone,
    reqbloodGroup: "",
    amountBlood: "",
    hospitalName: "",
  });

  const emaildata = {
    donorId: _id,
    donerName: name,
    donerEmail: email,
    donorContact: contact,
    donerBloodGroup: bloodGroup,
    patientDetails: RequestformData,
    patientId: data._id,
    date: new Date(),
  };

  const handleFormInput = (e) => {
    e.preventDefault();
    setRequestformData({
      ...RequestformData,
      [e.target.name]: e.target.value,
    });
  };

  const handleEmail = async (e) => {
    // try {
    //   const res = await fetch(`${BASE_URL}/doner/${data._id}`, {
    //     method: "post",
    //     headers: {
    //       "Content-Type": "application/json",
    //     },
    //     body: JSON.stringify(emaildata),
    //   });
    //   const result = await res.json();
    //   toast.success(result.message);
    //   setOpenModal(false);
    //   if (!res.ok) {
    //     toast.error(result.message);
    //     throw new Error(result.message);
    //   }
    // } catch (error) {
    //   console.log(error);
    //   toast.error(error);
    // }
    e.preventDefault();
    try {
      const res = await fetch(`${BASE_URL}/appointment/`, {
        method: "post",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(emaildata),
      });
      const result = await res.json();
      toast.success(result.message);
      setOpenModal(false);
      if (!res.ok) {
        toast.error(result.message);
        throw new Error(result.message);
      }
    } catch (error) {
      console.log(error);
      toast.error(error);
    }
  };

  return (
    <>
      <Link
        type="button"
        class="mt-8 inline-block rounded bg-backgroundColor px-12 py-3 text-sm font-medium text-white transition hover:bg-[#4d4d4d]"
        onClick={() => setOpenModal(true)}
      >
        Request for blood
      </Link>
      <Modal show={openModal} size="lg" onClose={onCloseModal} popup>
        <Modal.Header />
        <Modal.Body>
          <div className="space-y-8">
            <h3 className="text-xl font-medium text-gray-900 dark:text-white">
              Request blood form
            </h3>
            <form class="space-y-4" onSubmit={handleEmail}>
              <div className="grid grid-cols-2 gap-4 lg:grid-cols-2">
                <div>
                  <label
                    for="name"
                    class="block mb-2 text-sm font-medium text-gray-900"
                  >
                    Your name
                  </label>
                  <input
                    type="text"
                    name="name"
                    class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-backgroundColor-500 focus:border-backgroundColor-500 block w-full p-2.5 "
                    value={RequestformData.name}
                    onChange={handleFormInput}
                    required
                  />
                </div>
                <div>
                  <label
                    for="email"
                    class="block mb-2 text-sm font-medium text-gray-900 dark:text-white"
                  >
                    Your email
                  </label>
                  <input
                    type="email"
                    name="email"
                    id="email"
                    class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-backgroundColor-500 focus:border-backgroundColor-500 block w-full p-2.5 "
                    value={RequestformData.email}
                    onChange={handleFormInput}
                    required
                  />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4 lg:grid-cols-2">
                <div>
                  <label
                    for="number"
                    class="block mb-2 text-sm font-medium text-gray-900 dark:text-white"
                  >
                    Your number
                  </label>
                  <input
                    type="number"
                    name="number"
                    class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-backgroundColor-500 focus:border-backgroundColor-500 block w-full p-2.5 "
                    value={RequestformData.phone}
                    required
                    onChange={handleFormInput}
                  />
                </div>
                <div>
                  <label
                    for="text"
                    class="block mb-2 text-sm font-medium text-gray-900 dark:text-white"
                  >
                    Amount of blood required
                  </label>
                  <input
                    type="text"
                    name="amountBlood"
                    class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-backgroundColor-500 focus:border-backgroundColor-500 block w-full p-2.5 "
                    value={RequestformData.amountBlood}
                    onChange={handleFormInput}
                    required
                  />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4 lg:grid-cols-2">
                <div>
                  <label
                    for="reqbloodGroup"
                    class="block mb-2 text-sm font-medium text-gray-900 dark:text-white"
                  >
                    Required blood group
                  </label>
                  <input
                    type="text"
                    name="reqbloodGroup"
                    class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-backgroundColor-500 focus:border-backgroundColor-500 block w-full p-2.5 "
                    value={RequestformData.reqbloodGroup}
                    onChange={handleFormInput}
                    required
                  />
                </div>

                <div>
                  <label
                    for="hospitalName"
                    class="block mb-2 text-sm font-medium text-gray-900 dark:text-white"
                  >
                    Hospital name
                  </label>
                  <input
                    type="text"
                    name="hospitalName"
                    class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-backgroundColor-500 focus:border-backgroundColor-500 block w-full p-2.5 "
                    value={RequestformData.hospitalName}
                    onChange={handleFormInput}
                    placeholder="abc hospital karachi"
                    required
                  />
                </div>
              </div>
              <button
                type="submit"
                class="w-full text-white bg-backgroundColor hover:bg-[#4d4d4d] focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center"
                onClick={() => handleEmail(_id)}
              >
                Submit
              </button>
            </form>
          </div>
        </Modal.Body>
      </Modal>
    </>
  );
};

export default EmailSendModal;

import { createContext, useContext, useReducer } from "react";
import reducer from "./reducer/authReducer";
import { useEffect } from "react";
const AuthContext = createContext();

const AuthProvider = ({ children }) => {
  const initialState = {
    data: localStorage.getItem("data")
      ? JSON.parse(localStorage.getItem("data"))
      : [],
    token: localStorage.getItem("token"),
    role: localStorage.getItem("role"),
  };

  const [state, dispatch] = useReducer(reducer, initialState);

  const getUserData = (data, token, role) => {
    dispatch({ type: "LOGIN_SUCCESS", payload: { data, token, role } });
  };

  const getUserUpdate = (data) => {
    dispatch({ type: "UPDATE_DATA", payload: { data } });
  };

  const logOutUser = () => {
    dispatch({ type: "LOGOUT" });
  };

  useEffect(() => {
    localStorage.setItem("data", JSON.stringify(state.data));
    localStorage.setItem("token", state.token);
    localStorage.setItem("role", state.role);
  }, [state]);

  return (
    <AuthContext.Provider
      value={{ ...state, getUserData, logOutUser, getUserUpdate }}
    >
      {children}
    </AuthContext.Provider>
  );
};

const useAuthContext = () => {
  return useContext(AuthContext);
};

export { useAuthContext, AuthContext, AuthProvider };

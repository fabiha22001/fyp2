import {
  createContext,
  useContext,
  useReducer,
  useEffect,
  useState,
} from "react";
// import reducer from "./reducer/inventoryReducer";
import { BASE_URL } from "../../config";
const InventoryContext = createContext();

const InventoryProvider = ({ children }) => {
  //   const initalState = {
  //     data: [],
  //   };
  //   const [state, dispatch] = useReducer(reducer, initalState);
  const [inventory, setInventory] = useState([]);
  const [loading, setLoading] = useState(false);

  const getInventoryData = async () => {
    setLoading(true);
    try {
      const res = await fetch(`${BASE_URL}/inventory/`);
      const result = await res.json();
      if (!res.ok) {
        throw new Error(result.message);
      }
      setInventory(result.data);
      setLoading(false);
    } catch (error) {
      setLoading(false);
      toast.error(error.message);
    }
  };

  //   const getInventoryData = (data) => {
  //     dispatch({ type: "INVENTORY_DATA", payload: { data } });
  //   };
  //   const inventoryDataUpdate = (data) => {
  //     dispatch({ type: "INVENTORY_DATA_UPDATE", payload: { data } });
  //   };

  //   const deleteInventory = (id) => {
  //     dispatch({ type: "REMOVE_INVENTORY", payload: { id } });
  //   };

  useEffect(() => {
    getInventoryData();
  }, []);
  return (
    <InventoryContext.Provider value={{ getInventoryData, inventory, loading }}>
      {children}
    </InventoryContext.Provider>
  );
};

const useInventoryContext = () => {
  return useContext(InventoryContext);
};

export { useInventoryContext, InventoryContext, InventoryProvider };

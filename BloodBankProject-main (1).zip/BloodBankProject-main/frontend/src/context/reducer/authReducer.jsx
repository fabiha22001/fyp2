const authReducer = (state, action) => {
  switch (action.type) {
    case "LOGIN_SUCCESS":
      return {
        ...state,
        data: action.payload.data,
        token: action.payload.token,
        role: action.payload.role,
      };

    case "UPDATE_DATA":
      return {
        ...state,
        data: action.payload.data,
      };

    case "LOGOUT":
      return {
        data: [],
        token: "",
        role: "",
      };

    default:
      return state;
  }
};

export default authReducer;

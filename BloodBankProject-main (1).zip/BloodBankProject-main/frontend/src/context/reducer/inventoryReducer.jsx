// const inventoryReducer = (state, action) => {
//   switch (action.type) {
//     case "INVENTORY_DATA":
//       return {
//         ...state,
//         data: action.payload.data,
//       };
//     case "INVENTORY_DATA_UPDATE":
//       return {
//         ...state,
//         data: action.payload.data,
//       };
//     case "REMOVE_INVENTORY":
//       let inventoryItem = state.data.filter(
//         (elem) => elem.id !== action.payload
//       );
//       return {
//         ...state,
//         data: inventoryItem,
//       };

//     default:
//       return state;
//   }
// };

// export default inventoryReducer;

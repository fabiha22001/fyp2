import React from "react";
import Router from "../routes/Router";

const Layout = () => {
  return (
    <div>
      <Router />
    </div>
  );
};

export default Layout;
